from django.shortcuts import render, get_object_or_404, redirect
from django.urls import reverse_lazy
from django.contrib import messages
from django.db.models import Q
from .models import Recipe
from .forms import RecipeForm

def recipe_list(request):
    recipes = Recipe.objects.all()
    return render(request, 'recipes/recipe_list.html', {'recipes': recipes})

def recipe_search(request):
    query = request.GET.get('q', '')
    # Filter recipes by title or ingredients using case-insensitive matching
    recipes = Recipe.objects.filter(
        Q(title__icontains=query) | Q(ingredients__icontains=query)
    ).distinct() if query else Recipe.objects.all()
    return render(request, 'recipes/recipe_search.html', {'recipes': recipes, 'query': query})

def recipe_detail(request, slug):
    recipe = get_object_or_404(Recipe, slug=slug)
    # Assuming recipe.ingredients is a comma-separated string
    ingredients_list = recipe.ingredients.split(',') if recipe.ingredients else []
    context = {
        'recipe': recipe,
        'ingredients': ingredients_list,
    }
    return render(request, 'recipes/recipe_detail.html', context)

def recipe_confirm_delete(request):
    if request.method == 'POST':
        form = RecipeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Recipe added successfully!")
            return redirect(reverse_lazy('recipe_list'))
    else:
        form = RecipeForm()
    return render(request, 'recipes/recipe_form.html', {'form': form, 'title': 'Add Recipe'})

def recipe_update(request, slug):
    recipe = get_object_or_404(Recipe, slug=slug)
    if request.method == 'POST':
        form = RecipeForm(request.POST, request.FILES, instance=recipe)
        if form.is_valid():
            form.save()
            messages.success(request, "Recipe updated successfully!")
            return redirect('recipe_detail', slug=recipe.slug)
    else:
        form = RecipeForm(instance=recipe)
    return render(request, 'recipes/recipe_form.html', {'form': form, 'title': 'Edit Recipe'})
