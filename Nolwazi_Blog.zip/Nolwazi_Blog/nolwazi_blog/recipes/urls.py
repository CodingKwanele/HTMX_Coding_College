from django.urls import path
from . import views

urlpatterns = [
    path('', views.recipe_list, name='recipe_list'),
    path('search/', views.recipe_search, name='recipe_search'),
    path('recipe/<slug:slug>/', views.recipe_detail, name='recipe_detail'),
    path('add/', views.recipe_confirm_delete, name='recipe_confirm_delete'),
    path('edit/<slug:slug>/', views.recipe_update, name='recipe_update'),
    path('delete/<slug:slug>/', views.recipe_confirm_delete, name='recipe_confirm_delete'),
]
