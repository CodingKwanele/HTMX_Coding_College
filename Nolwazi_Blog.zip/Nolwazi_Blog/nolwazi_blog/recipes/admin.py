from django.contrib import admin
from .models import Recipe

admin.site.register(Recipe)
