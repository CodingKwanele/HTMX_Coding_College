from django.shortcuts import render
from django.http import HttpResponse, HttpResponseBadRequest

def example(request):
    """
    Renders the example.html template.
    """
    return render(request, "myapp/example.html")
    # 'myapp/example.html' matches the folder path: myapp/templates/myapp/example.html

def sample_post(request):
    """
    Handles the POST data from the form using HTMX.
    """
    if request.method == 'POST':
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        favourite_color = request.POST.get('favourite_color', '')

        # Validate
        if name and email and favourite_color:
            
            return HttpResponse(
            f'''
            <p class="success">Thank you, {name} ({email}). We recorded your color: {favourite_color}.</p>
            <script>
            document.body.style.background = "{favourite_color}";
            </script>
            '''
        )
        else:
            return HttpResponseBadRequest(
                '<p class="error">All fields are required. Please try again.</p>'
            )

    # If it's not a POST, just show an error or handle differently
    return HttpResponseBadRequest('Invalid request method.')
